import mysql.connector

config = {
    'user': 'root',
    'password': 'password',
    'host': 'localhost',
    'database': 'DrugstoreMohammadi'
}

def manage_pharmacy_data():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()
    
def insert_sample_data():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    # Insert sample patients
    sample_patients = [
        ('Ali', 'Hosseini', '1980-05-15', '09123456789', 'Tehran, Iran'),
        ('Maryam', 'Shahidi', '1992-08-22', '09351234567', 'Isfahan, Iran'),
        ('Reza', 'Ghorbani', '1975-11-03', '09129876543', 'Shiraz, Iran')
    ]
    for patient in sample_patients:
        cursor.execute('''
            INSERT INTO Patients (FirstName, LastName, BirthDate, PhoneNumber, Address)
            VALUES (%s, %s, %s, %s, %s)
        ''', patient)

    # Insert sample medicines
    sample_medicines = [
        ('Paracetamol', 'PARA123', 'Pharma Inc.', 5.50, 200),
        ('Ibuprofen', 'IBU456', 'HealthCo', 8.20, 150),
        ('Amoxicillin', 'AMOX789', 'MedLife', 12.00, 100)
    ]
    for medicine in sample_medicines:
        cursor.execute('''
            INSERT INTO Medicines (MedicineName, Code, Manufacturer, Price, Stock)
            VALUES (%s, %s, %s, %s, %s)
        ''', medicine)

    # Insert sample pharmacists
    sample_pharmacists = [
        ('Ali', 'Rostami', 'ali.rostami@example.com', '09123456789', 'Cardiology'),
        ('Sara', 'Karimi', 'sara.karimi@example.com', '09111223344', 'Dermatology'),
        ('Reza', 'Mohammadi', 'reza.mohammadi@example.com', '09332211000', 'Pediatrics')
    ]
    for pharmacist in sample_pharmacists:
        cursor.execute('''
            INSERT INTO Pharmacists (FirstName, LastName, Email, PhoneNumber, Specialty)
            VALUES (%s, %s, %s, %s, %s)
        ''', pharmacist)

    # Insert sample prescriptions
    sample_prescriptions = [
        (1, '2023-12-15', 'Dr. Ali Rostami'),
        (2, '2023-12-16', 'Dr. Sara Karimi'),
        (3, '2023-12-17', 'Dr. Reza Mohammadi')
    ]
    for prescription in sample_prescriptions:
        cursor.execute('''
            INSERT INTO Prescriptions (PatientID, DateIssued, DoctorName)
            VALUES (%s, %s, %s)
        ''', prescription)

    # Insert sample sales
    sample_sales = [
        (1, 1, 2),  # MedicineID, PatientID, Quantity
        (2, 2, 1),
        (3, 3, 3)
    ]
    for sale in sample_sales:
        cursor.execute('''
            INSERT INTO Sales (MedicineID, PatientID, Quantity)
            VALUES (%s, %s, %s)
        ''', sale)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    insert_sample_data()
