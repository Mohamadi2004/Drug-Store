import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.util import antiflood
import mysql.connector
from DDL import create_database, create_tables
from DML import manage_pharmacy_data

API_TOKEN = 'Your_token'
bot = telebot.TeleBot(API_TOKEN)

config = {
    'user': 'root',
    'password': 'password',
    'host': 'localhost',
    'database': 'DrugstoreMohammadi'
}

def execute_query(query, params=()):
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params)
    conn.commit()
    conn.close()

def fetch_query(query, params=()):
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params)
    result = cursor.fetchall()
    conn.close()
    return result

@bot.message_handler(commands=['start'])
def start(message):
    markup = InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton("ثبت بیمار جدید", callback_data="new_patient")
    btn2 = InlineKeyboardButton("مشاهده موجودی داروها", callback_data="view_medicines")
    btn3 = InlineKeyboardButton("ثبت نسخه جدید", callback_data="new_prescription")
    btn4 = InlineKeyboardButton("مشاهده نسخه‌ها", callback_data="view_prescriptions")
    btn5 = InlineKeyboardButton("اطلاعات دکترها", callback_data="view_pharmacists")

    markup.add(btn1, btn2)
    markup.add(btn3, btn4)
    markup.add(btn5)

    bot.send_message(message.chat.id, 'به ربات مدیریت داروخانه خوش آمدید! لطفاً یک گزینه را انتخاب کنید:', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_query_handler(call):
    cid = call.message.chat.id
    mid = call.message.message_id
    data = call.data

    if data == 'new_patient':
        bot.send_message(cid, "لطفاً نام بیمار را وارد کنید:")
        bot.register_next_step_handler(call.message, process_patient_first_name)

    elif data == 'view_medicines':
        medicines = fetch_query("SELECT MedicineName, Stock, Price FROM Medicines")
        medicines_text = "\nموجودی داروها:\n" + "\n".join([f"{m['MedicineName']}: {m['Stock']} عدد - قیمت: {m['Price']} تومان" for m in medicines])
        add_back_to_main_button(cid, mid, medicines_text)

    elif data == 'new_prescription':
        bot.send_message(cid, "لطفاً شناسه بیمار را وارد کنید:")
        bot.register_next_step_handler(call.message, process_patient_id)

    elif data == 'view_prescriptions':
        prescriptions = fetch_query("SELECT p.PrescriptionID, pa.FirstName, pa.LastName, p.DateIssued FROM Prescriptions p JOIN Patients pa ON p.PatientID = pa.PatientID")
        prescriptions_text = "\nلیست نسخه‌ها:\n" + "\n".join([f"نسخه {p['PrescriptionID']}: {p['FirstName']} {p['LastName']} - تاریخ: {p['DateIssued']}" for p in prescriptions])
        add_back_to_main_button(cid, mid, prescriptions_text)

    elif data == 'view_pharmacists':
        pharmacists = fetch_query("SELECT FirstName, LastName, Email FROM Pharmacists")
        pharmacists_text = "\nاطلاعات دکترها:\n" + "\n".join([f"{p['FirstName']} {p['LastName']} - ایمیل: {p['Email']}" for p in pharmacists])
        add_back_to_main_button(cid, mid, pharmacists_text)

    elif data == 'back_to_main':
        start(call.message)

def add_back_to_main_button(cid, mid, text):
    markup = InlineKeyboardMarkup()
    back_button = InlineKeyboardButton("بازگشت به منوی اصلی", callback_data="back_to_main")
    markup.add(back_button)
    bot.edit_message_text(text, chat_id=cid, message_id=mid, reply_markup=markup)

def process_patient_first_name(message):
    first_name = message.text
    bot.send_message(message.chat.id, "لطفاً نام خانوادگی بیمار را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_patient_last_name(first_name, msg))

def process_patient_last_name(first_name, message):
    last_name = message.text
    bot.send_message(message.chat.id, "لطفاً تاریخ تولد بیمار را به فرمت YYYY-MM-DD وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_patient_birth_date(first_name, last_name, msg))

def process_patient_birth_date(first_name, last_name, message):
    birth_date = message.text
    bot.send_message(message.chat.id, "لطفاً شماره تماس بیمار را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_patient_phone(first_name, last_name, birth_date, msg))

def process_patient_phone(first_name, last_name, birth_date, message):
    phone = message.text
    bot.send_message(message.chat.id, "لطفاً آدرس بیمار را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: finalize_patient_registration(first_name, last_name, birth_date, phone, msg))

def finalize_patient_registration(first_name, last_name, birth_date, phone, message):
    address = message.text
    execute_query('''
        INSERT INTO Patients (FirstName, LastName, BirthDate, PhoneNumber, Address)
        VALUES (%s, %s, %s, %s, %s)
    ''', (first_name, last_name, birth_date, phone, address))
    bot.send_message(message.chat.id, "ثبت بیمار جدید با موفقیت انجام شد.")
    start(message)

def process_patient_id(message):
    patient_id = message.text
    bot.send_message(message.chat.id, "لطفاً نام دارو را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_prescription(patient_id, msg))

def process_prescription(patient_id, message):
    medicine_name = message.text
    bot.send_message(message.chat.id, f"نسخه برای بیمار {patient_id} با داروی {medicine_name} ثبت شد.")

def process_medicine_id(message):
    medicine_id = message.text
    bot.send_message(message.chat.id, "لطفاً تعداد فروش را وارد کنید:")
    bot.register_next_step_handler(message, lambda msg: process_sale(medicine_id, msg))

def process_sale(medicine_id, message):
    quantity = message.text
    execute_query('''
        INSERT INTO Sales (MedicineID, Quantity) VALUES (%s, %s)
    ''', (medicine_id, quantity))
    bot.send_message(message.chat.id, "فروش با موفقیت ثبت شد.")

@bot.message_handler(commands=['help'])
def command_help_handler(message):
    pharmacy_address = "آدرس داروخانه: تهران، خیابان آزادی، پلاک 222"
    bot.send_message(message.chat.id, pharmacy_address)

if __name__ == '__main__':
    bot.polling(none_stop=True)
