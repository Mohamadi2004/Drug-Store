import mysql.connector

config = {'user': 'root', 'password': 'password', 'host': 'localhost', 'database': 'DrugstoreMohammadi'}

def create_database():
    conn = mysql.connector.connect(user=config['user'], password=config['password'], host=config['host'])
    cursor = conn.cursor()
    cursor.execute("DROP DATABASE IF EXISTS DrugstoreMohammadi")
    cursor.execute("CREATE DATABASE DrugstoreMohammadi")
    conn.close()

def create_tables():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    # Table for Patients
    cursor.execute('''
        CREATE TABLE Patients (
            PatientID INT PRIMARY KEY AUTO_INCREMENT,
            FirstName VARCHAR(100) NOT NULL,
            LastName VARCHAR(100) NOT NULL,
            BirthDate DATE NOT NULL,
            PhoneNumber VARCHAR(15),
            Address TEXT
        )
    ''')

    # Table for Medicines
    cursor.execute('''
        CREATE TABLE Medicines (
            MedicineID INT PRIMARY KEY AUTO_INCREMENT,
            MedicineName VARCHAR(100) NOT NULL,
            Code VARCHAR(50) UNIQUE NOT NULL,
            Manufacturer VARCHAR(100),
            Price DECIMAL(10, 2) NOT NULL,
            Stock INT NOT NULL
        )
    ''')

    # Table for Prescriptions
    cursor.execute('''
        CREATE TABLE Prescriptions (
            PrescriptionID INT PRIMARY KEY AUTO_INCREMENT,
            PatientID INT NOT NULL,
            DateIssued DATE NOT NULL,
            DoctorName VARCHAR(100),
            FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE
        )
    ''')

    # Table for Pharmacists
    cursor.execute('''
        CREATE TABLE Pharmacists (
            PharmacistID INT PRIMARY KEY AUTO_INCREMENT,
            FirstName VARCHAR(100) NOT NULL,
            LastName VARCHAR(100) NOT NULL,
            Email VARCHAR(100) UNIQUE NOT NULL,
            PhoneNumber VARCHAR(15),
            Specialty VARCHAR(100)
        )
    ''')

    # Table for Sales
    cursor.execute('''
        CREATE TABLE Sales (
            SaleID INT PRIMARY KEY AUTO_INCREMENT,
            MedicineID INT NOT NULL,
            PatientID INT,
            Quantity INT NOT NULL,
            SaleDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (MedicineID) REFERENCES Medicines(MedicineID) ON DELETE CASCADE,
            FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE SET NULL
        )
    ''')

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
    create_tables()
